# WKO Scraper
Scraped Firmenlisten von WKO.at für definierte Bezirke.

## Run locally
```
npm install
APIFY_LOCAL_STORAGE_DIR=./storage node main.js
```
